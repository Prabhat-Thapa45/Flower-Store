""" This acts as a database for our project """

STOCK = [
    {"flower_name": "Rose", "quantity": 20, "price": 4.50},
    {"flower_name": "Lily", "quantity": 20, "price": 5.50},
]

BQ_SIZE = [0]

YOUR_CART = []
